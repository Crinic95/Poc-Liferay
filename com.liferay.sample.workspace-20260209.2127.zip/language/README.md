Put your language keys in `Language.properties`. Run `../gradlew buildLang` to generate translations.

Translations with `(Automatic copy)` are ignored. Translations for disabled locales are also ignored.

Enable locales from the UI or by setting the property `locales.enabled` in `portal-ext.properties`.