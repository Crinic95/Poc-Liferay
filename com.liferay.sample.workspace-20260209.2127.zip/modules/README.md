Client extensions are the recommended way of customizing Liferay. Modules and
themes are supported for backwards compatibility.